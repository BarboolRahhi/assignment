package com.cg.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.cg.entity.Emp;

@Service
public class EmpService implements IEmpSer {
	
	private static Map<Integer, Emp> emap = new HashMap<Integer, Emp>();
	
	static {
		emap.put(1001, new Emp(1001, "rahhi", 2200, "hr"));
	}

	@Override
	public Emp getEmployee(int eid) {
		return emap.get(eid);
	}
	
	@Override
	public List<Emp> getEmployee() {
		return new ArrayList(emap.values());
	}

	@Override
	public boolean addEmployee(Emp emp) {
		emap.put(emp.getEmpId(), emp);
		return true;
	}

}
