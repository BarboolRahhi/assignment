package com.cg.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.entity.Emp;
import com.cg.service.EmpService;

@Controller
public class EmpController {
	
	@Autowired
	private EmpService service;

	@RequestMapping("addform")
	public String showAddEmpForm(Model  model) {
		
		model.addAttribute("emodel", new Emp());
		return "AddEmpPage";
	}
	
	@PostMapping("add")
	public String addEmployee(@Valid @ModelAttribute("emodel") Emp emp, BindingResult br,Model  model) {
		if(br.hasErrors())
			return "AddEmpPage";
		model.addAttribute("msg", "Employee Added Successfully");
		service.addEmployee(emp);
		model.addAttribute("elist", service.getEmployee());
		return "AddEmpResultPage";
	}
	
}
