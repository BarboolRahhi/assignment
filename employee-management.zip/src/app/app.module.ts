import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { ViewallComponent } from "./employee/viewall/viewall.component";
import { AddEmpComponent } from "./employee/add-emp/add-emp.component";
import { ViewByIdComponent } from './employee/view-by-id/view-by-id.component';
import { ViewByDeptComponent } from './employee/view-by-dept/view-by-dept.component';

@NgModule({
  declarations: [AppComponent, ViewallComponent, AddEmpComponent, ViewByIdComponent, ViewByDeptComponent],
  imports: [BrowserModule, AppRoutingModule, FormsModule, HttpClientModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
