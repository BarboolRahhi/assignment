import { Department } from "./department";

export class Employee {
  public empId: number;
  public empName: String;
  public empSal: number;
  public doj: string;
  public strDoj: string;
  public dept: Department;

  constructor(
    empId: number,
    empName: String,
    empSal: number,
    doj: string,
    dept: Department
  ) {
    this.empId = empId;
    this.empName = empName;
    this.empSal = empSal;
    this.doj = doj;
    this.dept = dept;
  }
}
