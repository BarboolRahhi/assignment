export class Department {
  public deptId: number;
  public deptName: string;
}
