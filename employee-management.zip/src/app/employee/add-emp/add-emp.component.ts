import { Component, OnInit, ViewChild } from "@angular/core";
import { Employee } from "src/app/model/employee";
import { EmployeeService } from "src/app/employee.service";
import { NgForm } from "@angular/forms";
import { Department } from "src/app/model/department";
import { ActivatedRoute } from "@angular/router";

@Component({
  selector: "app-add-emp",
  templateUrl: "./add-emp.component.html",
  styleUrls: ["./add-emp.component.css"],
})
export class AddEmpComponent implements OnInit {
  @ViewChild("f") addForm: NgForm;
  employee: Employee;
  departments: Department[];
  errorMsg: string;
  successMsg: string;
  eid: number;
  editMode: boolean = false;

  constructor(
    private empService: EmployeeService,
    private activateRoute: ActivatedRoute
  ) {}

  ngOnInit() {
    this.empService.viewallDept().subscribe((data) => {
      this.departments = data;
      this.addForm.form.patchValue({ dept: this.departments[0] });
    });

    this.activateRoute.params.subscribe((params) => {
      this.eid = +params["eid"];
      this.editMode = params["eid"] != null;
      this.setEditEmp();
    });
  }

  addEmp() {
    const formObj = this.addForm.value;
    let department = this.departments.filter(
      (dept) => (dept.deptId = formObj.deptId)
    )[0];
    let employee = new Employee(
      formObj.empId,
      formObj.empName,
      formObj.empSal,
      formObj.doj,
      department
    );
    console.log(employee);
    if (this.editMode) {
      this.empService.updateEmp(employee).subscribe(
        (response: { message: string }) => {
          console.log(response);
          this.successMsg = response.message;
          this.errorMsg = null;
        },
        (err) => {
          console.log(err.error.message);
          this.errorMsg = err.error.message;
          this.successMsg = null;
        }
      );
    } else {
      this.empService.addEmp(employee).subscribe(
        (response: { message: string }) => {
          console.log(response);
          this.successMsg = response.message;
          this.errorMsg = null;
          this.addForm.reset();
        },
        (err) => {
          console.log(err.error.message);
          this.errorMsg = err.error.message;
          this.successMsg = null;
        }
      );
    }
  }

  setEditEmp() {
    if (this.editMode) {
      this.empService.viewById(this.eid).subscribe((data) => {
        this.employee = data;
        this.addForm.setValue({
          empId: this.employee.empId,
          empName: this.employee.empName,
          empSal: this.employee.empSal,
          doj: this.employee.doj,
          deptId: this.employee.dept.deptId,
        });
      });
    }
  }
}
