import { Component, OnInit, ViewChild } from "@angular/core";
import { Employee } from "src/app/model/employee";
import { NgForm } from "@angular/forms";
import { EmployeeService } from "src/app/employee.service";

@Component({
  selector: "app-view-by-id",
  templateUrl: "./view-by-id.component.html",
  styleUrls: ["./view-by-id.component.css"],
})
export class ViewByIdComponent implements OnInit {
  @ViewChild("f") findForm: NgForm;
  emp: Employee;
  message: string;
  formState: boolean = false;
  errorState: boolean = false;

  constructor(private empService: EmployeeService) {}

  ngOnInit() {}

  find() {
    console.log(this.findForm.value.eid);
    this.empService.viewById(this.findForm.value.eid).subscribe(
      (data) => {
        this.formState = true;
        this.errorState = false;
        this.emp = data;
      },
      (err) => {
        console.log(err.error.message);
        this.errorState = true;
        this.formState = false;
        this.message = err.error.message;
      }
    );
  }
}
