import { Component, OnInit } from "@angular/core";
import { EmployeeService } from "src/app/employee.service";
import { Employee } from "src/app/model/employee";
import { Router } from "@angular/router";

@Component({
  selector: "app-viewall",
  templateUrl: "./viewall.component.html",
  styleUrls: ["./viewall.component.css"],
})
export class ViewallComponent implements OnInit {
  employees: Employee[];
  errorMsg: string;
  successMsg: string;

  constructor(private empService: EmployeeService, private route: Router) {}

  ngOnInit() {
    this.empService.fetchViewall();
    this.empService.employeesChanged.subscribe((data) => {
      this.employees = data;
    });
  }

  onDelete(eid: number) {
    console.log(eid);
    this.empService.deleteEmp(eid).subscribe(
      (response: { message: string }) => {
        console.log(response);
        this.empService.fetchViewall();
        alert(response.message);
      },
      (err) => {
        console.log(err.error);
      }
    );
  }

  onEdit(eid: number) {
    console.log(eid);
    this.route.navigate(["update", eid]);
  }
}
