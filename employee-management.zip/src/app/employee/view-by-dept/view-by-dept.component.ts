import { Component, OnInit, ViewChild } from "@angular/core";
import { Employee } from "src/app/model/employee";
import { EmployeeService } from "src/app/employee.service";
import { NgForm } from "@angular/forms";
import { Department } from "src/app/model/department";

@Component({
  selector: "app-view-by-dept",
  templateUrl: "./view-by-dept.component.html",
  styleUrls: ["./view-by-dept.component.css"],
})
export class ViewByDeptComponent implements OnInit {
  @ViewChild("f") findForm: NgForm;
  employees: Employee[];
  departments: Department[];

  constructor(private empService: EmployeeService) {}

  ngOnInit() {
    this.empService.viewallDept().subscribe((data) => {
      this.departments = data;
    });
  }

  find() {
    this.empService.viewByDept(this.findForm.value.deptName);
    this.empService.employeesDeptChanged.subscribe((data) => {
      this.employees = data;
    });
  }

  onDelete(eid: number) {
    console.log(eid);
    this.empService.deleteEmp(eid).subscribe(
      (response: { message: string }) => {
        console.log(response);
        this.empService.viewByDept(this.findForm.value.deptName);
        alert(response.message);
      },
      (err) => {
        console.log(err.error);
      }
    );
  }
}
