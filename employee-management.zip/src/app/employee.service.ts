import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Employee } from "./model/employee";
import { Department } from "./model/department";
import { map } from "rxjs/operators";
import { Subject } from "rxjs";

@Injectable({
  providedIn: "root",
})
export class EmployeeService {
  private baseUrl = "http://localhost:8083/springrest/";
  constructor(private http: HttpClient) {}

  employeesChanged = new Subject<Employee[]>();
  employeesDeptChanged = new Subject<Employee[]>();

  fetchViewall() {
    this.http.get<Employee[]>(this.baseUrl + "viewall").subscribe((data) => {
      this.employeesChanged.next(data);
    });
  }

  viewallDept() {
    return this.http.get<Department[]>(this.baseUrl + "viewallDept");
  }

  viewById(eid: number) {
    return this.http.get<Employee>(this.baseUrl + `viewById/${eid}`);
  }

  viewByDept(name: String) {
    this.http
      .get<Employee[]>(this.baseUrl + `viewByDept/${name}`)
      .subscribe((data) => {
        this.employeesDeptChanged.next(data);
      });
  }

  addEmp(employee: Employee) {
    return this.http.post(this.baseUrl + "add", employee);
  }

  updateEmp(employee: Employee) {
    return this.http.put(this.baseUrl + "update", employee);
  }

  deleteEmp(eid: number) {
    return this.http.delete(this.baseUrl + `delete/${eid}`);
  }
}
