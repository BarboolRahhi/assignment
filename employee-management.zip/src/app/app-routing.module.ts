import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { ViewallComponent } from "./employee/viewall/viewall.component";
import { AddEmpComponent } from "./employee/add-emp/add-emp.component";
import { ViewByIdComponent } from "./employee/view-by-id/view-by-id.component";
import { ViewByDeptComponent } from "./employee/view-by-dept/view-by-dept.component";

const routes: Routes = [
  { path: "viewall", component: ViewallComponent },
  { path: "addEmp", component: AddEmpComponent },
  { path: "update/:eid", component: AddEmpComponent },
  { path: "viewById", component: ViewByIdComponent },
  { path: "viewByDept", component: ViewByDeptComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
