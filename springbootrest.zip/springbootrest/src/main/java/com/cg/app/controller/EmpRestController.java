package com.cg.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.app.dao.IEmpDao;
import com.cg.app.entity.Dept;
import com.cg.app.entity.Emp;
import com.cg.app.exception.EmpIdException;
import com.cg.app.exception.EmpNotFoundException;
import com.cg.model.ResponseModel;

import net.bytebuddy.implementation.bytecode.Throw;

@RestController
@CrossOrigin
public class EmpRestController {
	
	@Autowired
	private IEmpDao dao;
	
	@GetMapping("/viewall")
	public List<Emp> getEmployees() {
		return dao.viewEmp();
	}
	
	@GetMapping("/viewallDept")
	public List<Dept> getDepartment() {
		return dao.viewDepts();
	}
	
	@GetMapping("/viewById/{eid}")
	public Emp getEmployeeById(@PathVariable int eid) throws EmpNotFoundException {
		Emp emp = dao.viewEmp(eid);
		if (emp == null) throw new EmpNotFoundException();
		return emp;
	}
	
	@GetMapping("/viewByDept/{deptName}")
	public List<Emp> getEmployeeByDept(@PathVariable String deptName) {
		List<Emp> empList = dao.viewEmp(deptName);
		return empList;
	}
	
	@PostMapping("/add") 
	public ResponseModel addEmployee(@RequestBody Emp emp) throws EmpIdException {
		ResponseModel responseModel = new ResponseModel(HttpStatus.OK.toString(), "Successfully Added");
		try {
			dao.addEmp(emp);
			return responseModel;
		} catch (Exception e) {
			throw new EmpIdException();
		}
	}
	
	@DeleteMapping("/delete/{eid}")
	public ResponseModel deleteEmployee(@PathVariable int eid) throws Exception {
		ResponseModel responseModel = new ResponseModel(HttpStatus.OK.toString(), "Successfully Deleted");
		if (dao.deleteEmp(eid)) {
			return responseModel;
		} else {
			throw new RuntimeException("Employee does not delete!");
		}	
	}
	
	@PutMapping("/update")
	public ResponseModel updateEmployee(@RequestBody Emp emp) throws Exception {
		ResponseModel responseModel = new ResponseModel(HttpStatus.OK.toString(), "Successfully Updated");
		if (dao.editEmp(emp)) {
			return responseModel;
		} else {
			throw new RuntimeException("Employee does not update");
		}	
	}
}
