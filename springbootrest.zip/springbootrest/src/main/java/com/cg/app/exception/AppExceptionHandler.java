package com.cg.app.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;


@ControllerAdvice
public class AppExceptionHandler {
	
	@ExceptionHandler(value = { EmpIdException.class })
	@ResponseStatus(code = HttpStatus.BAD_REQUEST, reason = "Id already exists")
	@ResponseBody
	public void handleIdException(Exception ex) {}
	
	@ExceptionHandler(value = { EmpNotFoundException.class })
	@ResponseStatus(code = HttpStatus.NOT_FOUND, reason = "Employee Not Found")
	@ResponseBody
	public void handleNotFoundException(Exception ex) {}
	
	@ExceptionHandler(value = { HttpMessageNotReadableException.class })
	@ResponseBody
	public ErrorInfo handleErrorException(Exception ex) {
		if (ex.getMessage().contains("doj")) {
			return new ErrorInfo("Date must have the patten yyyy-M-d");
		}
		return new ErrorInfo(ex.getMessage());
	}
	
	

}
