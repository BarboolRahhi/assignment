package com.company;

import org.springframework.context.ApplicationContext;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        RestTemplate restTemplate = new RestTemplate();
        String urlAdd = "http://localhost:8083/springrest/add";
        Emp emp = new Emp();
        emp.setEmpId(2001);
        emp.setEmpName("Rajeev Kumar");
        emp.setEmpSal(50000);
        emp.getDept().setDeptId(8);
        emp.setDoj(LocalDate.of(2016, 3, 15));
        try {
            ResponseModel resp = restTemplate.postForObject(urlAdd, emp, ResponseModel.class);
            System.out.println(resp);
        } catch (HttpClientErrorException e) {
            System.out.println(e.getResponseBodyAsString());
        }
        String url = "http://localhost:8083/springrest/viewall";
            ResponseEntity<List<Emp>> resp = restTemplate.exchange(url, HttpMethod.GET, null,
                    new ParameterizedTypeReference<List<Emp>>() {
                    });
            List<Emp> lst = resp.getBody();
            lst.forEach(System.out::println);


    }
}
